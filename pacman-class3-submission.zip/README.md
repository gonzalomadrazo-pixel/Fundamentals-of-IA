# Class 3 — Training a Ms. Pac-Man DQN Agent

> Submission for the Class 3 assignment ("Train a Ms. Pac-Man Agent"). This section is the
> grading entry point for that assignment. (This repository also holds unrelated
> coursework from other classes — the MNIST-from-scratch notebook and the class-signup
> frontend — which are not part of this submission.)
>
> **Note on other files in this repo:** any file here named `Pacman` or `Pacman V3` (no
> `.ipynb` extension) is *not* part of this assignment — they are earlier, misnamed copies
> of the Class 2 MNIST-from-scratch notebook. The only notebook for this assignment is
> [`pacman_dqn.ipynb`](./pacman_dqn.ipynb), linked throughout this README.

## Overview

`pacman_dqn.ipynb` trains a Deep Q-Network (DQN) to play *Ms. Pac-Man* (Atari, via
Gymnasium/ALE) and evaluates it against an untrained baseline on the same five seeds
before and after training.

**Run it yourself:**
1. Open [`pacman_dqn.ipynb`](./pacman_dqn.ipynb) in Google Colab (badge at the top of the
   notebook) or locally in Jupyter/VS Code with a Python 3.11-3.13 kernel.
2. In Colab, set **Runtime -> Change runtime type -> T4 GPU**.
3. Section 1 already contains my three chosen hyperparameters (below) — no edits needed to
   reproduce this run. Choose **Run All**.

## My three hyperparameters

| Setting | Value | Why |
|---|---|---|
| Exploration | **0.15** (15%) | Lower than the 0.20 starting point, so that once the 1,000-decision warm-up ends the agent leans more on what it has learned than on random moves. |
| Episodes | **800** | I wanted a much longer run than the notebook's 100-episode starting point to see whether score kept improving with a larger training budget. |
| Learning rate | **0.00005** (5e-5) | Lower than the 0.0001 reference point, on the theory that 8x more episodes than the starting point called for smaller, steadier weight updates rather than large ones over that many decisions. |

All other settings (seed, replay size, batch size, warm-up, target-network sync,
gamma, evaluation seeds/exploration) are the notebook's fixed classroom settings and were
not changed.

## What I expected vs. what happened

**Expected:** a substantially higher mean evaluation score than baseline, climbing fairly
steadily as training progressed.

**Observed:** mean score rose from **492.0 (before)** to **1046.0 (after)** — a **+554.0**
change (+113%), and every one of the five evaluation games individually improved. But the
improvement was *not* steady across all 800 episodes — see "Limitation" below.

## How I got to these three numbers (five earlier attempts, and what each one taught me)

This 800-episode run was not my first attempt — I iterated on this with Claude across
several runs first, and each one changed what I understood about the notebook:

1. **exploration=0.99, episodes=200, learning_rate=0.1001.** My first, naive guess. 99%
   random moves after warm-up meant the network was essentially training on noise, and a
   learning rate roughly 1,000x above the stable Adam range for this network (1e-4 to 2.5e-4)
   is likely to make weight updates overshoot badly. The evaluation score actually fell
   *below* the untrained baseline.
2. **exploration=0.15, episodes=100, learning_rate=0.0001.** My attempted fix — but the
   training-exploration panel came back flat at 1.0 again, identical to run 1. I had edited
   the three settings but not re-run section 5a, which is what actually resets the model,
   optimizer, and replay memory; without that, the notebook silently trains on stale values.
   **Lesson: any settings change needs a rerun from 5a (or a full Run All), not just
   re-running the training cell.**
3. A clean rerun at the same 0.15/100/0.0001 confirmed the exploration panel now behaved
   correctly (dropping from 1.0 to 0.15 after warm-up).
4. **exploration=0.15, episodes=500, learning_rate=0.00025.** I changed two things at once
   here (episodes *and* learning rate together), which breaks the notebook's own
   one-variable-at-a-time instruction — I knew this going in and did it anyway to save time,
   which made the result harder to interpret. Loss climbed continuously to ~0.15-0.2 and
   never flattened; the raw score plateaued by around episode 100 despite the extra 400
   episodes of training.
5. **exploration=0.15, episodes=500, learning_rate=0.0001.** Reverting just the learning
   rate, to isolate its effect. Loss growth was slower and lower (topping ~0.13-0.19) but
   still climbing, never flattening. The before/after score gap closed substantially (from
   -272 to -36) but still hadn't clearly beaten baseline.
6. **This submitted run: exploration=0.15, episodes=800, learning_rate=0.00005.** I lowered
   the learning rate again and, at the same time, raised episodes from 500 to 800 — so, like
   run 4, this changes two variables from the prior run rather than one. I made that call
   because episode count had shown itself to be the single biggest lever for giving the
   network more gradient updates, and every earlier attempt showed loss still climbing even
   as the learning rate came down; I wanted the best chance at a clear result given limited
   time left, rather than another inconclusive one. It worked: this is the first run where
   the mean evaluation score clearly and consistently beat baseline on all five games rather
   than just narrowing the gap.

**Why I stopped here:** with midterms in other courses this week, I could not spend more
time on the fully isolated follow-up test that this result actually calls for (e.g., 800
episodes at the *previous* learning rate of 0.0001 alone, or 500 episodes at 0.00005 alone)
to cleanly attribute the improvement to the lower learning rate versus the longer run versus
their combination. I'm reporting the combined-change result honestly, together with this
history, rather than presenting it as a single clean one-variable experiment.

### All five before/after evaluation scores (final, submitted run)

| Game (seed) | Before | After |
|---:|---:|---:|
| 1 (101) | 350 | 1170 |
| 2 (202) | 500 | 910 |
| 3 (303) | 320 | 700 |
| 4 (404) | 800 | 1560 |
| 5 (505) | 490 | 890 |
| **Mean** | **492.0** | **1046.0** |

Full record: [`results/comparison.json`](./results/comparison.json). Neither the before nor
after runs hit the 3,000-decision time limit on any of the five games (0/5 time-limited in
both).

### Training plot

![Training dashboard](./results/training_dashboard.png)

Left: raw score per training game (light blue) and a 25-game rolling average (orange), over
all 800 completed episodes. Middle: mean loss per update. Right: exploration rate (100%
during the 1,000-decision warm-up, then constant at 15%).

## Gameplay

**Before training** (untrained network):

![Untrained gameplay](./results/untrained_gameplay.gif)

**After training** (best of the five final evaluation games):

![Trained gameplay](./results/trained_best_gameplay.gif)

**Intermediate checkpoints** — this run passed 25 episodes many times over, so a gameplay
sample and checkpoint were saved every 25 episodes (32 checkpoints total, episode 25 through
episode 800). A few representative ones:

| Episode 25 | Episode 200 | Episode 450 | Episode 800 |
|---|---|---|---|
| ![ep25](./results/checkpoint_gifs/episode_0025.gif) | ![ep200](./results/checkpoint_gifs/episode_0200.gif) | ![ep450](./results/checkpoint_gifs/episode_0450.gif) | ![ep800](./results/checkpoint_gifs/episode_0800.gif) |

All 32 intermediate GIFs are in [`results/checkpoint_gifs/`](./results/checkpoint_gifs/),
and their single-game demo scores (one noisy evaluation game per checkpoint, at 15%
exploration — noisier than the 5-game/5%-exploration comparison above) are in
[`results/checkpoint_demo_scores.csv`](./results/checkpoint_demo_scores.csv).

## Training budget actually used

- **Completed episodes:** 800 of 800 requested.
- **Hardware:** CUDA GPU (Colab T4-class), Python 3.12.13, torch 2.11.0+cu128.
- **Decisions / learning updates / elapsed time:** the notebook prints running totals
  during training, but Colab truncates very long single-cell text output to only its last
  ~3.6-4.0k characters — repeatedly, once per 25-episode checkpoint in this run — so the
  full episode-by-episode print log visible in the notebook has gaps (e.g. episodes
  683-700, 707-725 are missing from the printed text). The last progress line still visible
  is **episode 782/800: 480,000 decisions, 119,751 learning updates, 29.8 minutes
  elapsed**. That the run nonetheless completed all 800 episodes (rather than stopping
  around 782) is evidenced independently by: all 32 checkpoint GIFs existing through
  episode 800, `training_dashboard.png`'s x-axis running to episode 800, and the absence of
  any "Stopped early" interrupt message or exception in the notebook — the code only reaches
  the section-6 evaluation cells after its training loop exits normally. See
  [`results/training_summary.json`](./results/training_summary.json) for the full note.
- Full config as run: [`results/config.json`](./results/config.json).

## What the agent observes, does, and is rewarded for

- **Observations:** four stacked 84x84 grayscale game screens (so the network can infer
  motion, not just a single static position).
- **Actions:** the 9 joystick moves Ms. Pac-Man supports — NOOP, UP, RIGHT, LEFT, DOWN, and
  the four diagonals.
- **Reward:** the in-game score change at each decision (pellets, power pellets, eaten
  ghosts), clipped to [-1, +1] during training so no single event dominates one update.

## One limitation

Even in this best run, the improvement did not build steadily across all 800 episodes.
`results/training_dashboard.png` shows the same pattern every earlier attempt showed, just
less severe: the 25-game rolling-average score climbs until roughly episode 100-300
(peaking near a ~950-1,000 rolling average), then flattens and drifts back down toward
episode 800 (to roughly 600-700), and mean update loss plateaus around 0.08-0.10 for the
~700 episodes after that instead of continuing to fall. Loss failing to fully flatten showed
up at *every* learning rate I tried across all six runs (0.1001, 0.00025, 0.0001, 0.00005) —
only the severity changed. That consistency across five different settings suggests this may
be close to a real ceiling from the notebook's fixed architecture (5,000-item replay buffer,
vanilla DQN with no Double-DQN) rather than something the three sliders alone can fully fix.
The single-game checkpoint demo score is also highly variable (300 at episode 775 vs. 2,530
at episode 600), which is expected from one noisy game per checkpoint but makes any single
checkpoint unreliable evidence on its own.

## Proposed next experiment

Two candidates, to make up for changing two variables at once in the final run: **(a)** hold
episodes at 800 and raise the learning rate back to 0.0001, to see how much of this run's
gain came from the longer run alone versus the lower learning rate; or **(b)** hold learning
rate at 0.00005 and drop episodes back to 500, for the same reason from the other direction.
Either isolates the one variable I didn't this time. (Proposed, not run — time didn't allow a
seventh training pass this week.)

## Files in this submission

- [`pacman_dqn.ipynb`](./pacman_dqn.ipynb) — the executed notebook, saved with all cell
  outputs from the final (and only) 800-episode run, plus a filled-in explanation cell at
  the bottom (section 7).
- [`results/training_dashboard.png`](./results/training_dashboard.png) — training plot.
- [`results/untrained_gameplay.gif`](./results/untrained_gameplay.gif),
  [`results/trained_best_gameplay.gif`](./results/trained_best_gameplay.gif) — before/after
  gameplay.
- [`results/checkpoint_gifs/`](./results/checkpoint_gifs/) — all 32 intermediate gameplay
  checkpoints (episode 25 through 800, every 25 episodes).
- [`results/checkpoint_demo_scores.csv`](./results/checkpoint_demo_scores.csv) — the 32
  single-game checkpoint demo scores.
- [`results/config.json`](./results/config.json),
  [`results/comparison.json`](./results/comparison.json),
  [`results/training_summary.json`](./results/training_summary.json) — run configuration and
  results, reconstructed from this notebook's own code and printed output (see note below).

**On `config.json` / `training.csv` / `training_summary.json`:** the notebook writes these
directly into Colab's temporary runtime storage and bundles them into a ZIP for manual
download at the end of the run (section 7). That ZIP was downloaded during the session but
was not additionally uploaded to this repository, and the runtime itself is gone, so the
three JSON files above were reconstructed from this notebook's own source code and printed
output rather than copied byte-for-byte from disk — every value in them traces directly to a
cell in `pacman_dqn.ipynb`. A full per-episode `training.csv` (800 rows) could not be
reconstructed this way, since individual episode scores were only ever written to disk, not
printed; `results/checkpoint_demo_scores.csv` (32 rows, one per checkpoint) and
`training_dashboard.png` (the actual full 800-episode curve, plotted from the in-memory data)
are what's available in its place. Model checkpoints (`.pt` files) are not included in this
repository to keep it small; they are in the ZIP downloaded from Colab.
